
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        AccountDAO dao = new AccountDAO();
        BankOperations bank = new BankOperations();
        TransactionDAO transactionDAO = new TransactionDAO();

        System.out.println("===== SECUREBANK =====");
        System.out.print("Enter account number: ");
        int accountNo = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter PIN: ");
        String pin = sc.nextLine();

        if (!dao.verifyPin(accountNo, pin)) {
            System.out.println("\nLogin failed. Access denied.");
            sc.close();
            return;
        }

        System.out.println("\nLogin successful!");
        System.out.println("Welcome to SecureBank!");

        int choice = 0;
        do {
            System.out.println("\n===== BANKING MENU =====");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer");
            System.out.println("5. Transaction History");
            System.out.println("6. Add Yearly Savings Interest");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    bank.showBalance(accountNo);
                    break;
                case 2:
                    System.out.print("Enter deposit amount: ");
                    bank.deposit(accountNo, sc.nextDouble());
                    break;
                case 3:
                    System.out.print("Enter withdrawal amount: ");
                    try {
                        bank.withdraw(accountNo, sc.nextDouble());
                    } catch (InsufficientFundsException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    System.out.print("Enter receiver account number: ");
                    int receiverAccount = sc.nextInt();
                    System.out.print("Enter transfer amount: ");
                    double transferAmount = sc.nextDouble();
                    try {
                        bank.transfer(accountNo, receiverAccount, transferAmount);
                    } catch (InsufficientFundsException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    transactionDAO.showLastFiveTransactions(accountNo);
                    break;
                case 6:
                    bank.addYearlyInterest(accountNo);
                    break;
                case 7:
                    System.out.println("Thank you for using SecureBank!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 7);

        sc.close();
    }
}
