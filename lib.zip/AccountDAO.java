
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AccountDAO {
    public boolean createAccount(int accountNo, String holderName,
                                 String accountType, double balance,
                                 String pin) {
        if (pin == null || !pin.matches("\\d{4,12}")) {
            System.out.println("PIN must contain 4 to 12 digits.");
            return false;
        }
        if (holderName == null || holderName.trim().isEmpty()
                || balance < 0 || !Double.isFinite(balance)
                || accountType == null
                || !(accountType.equalsIgnoreCase("SAVINGS")
                || accountType.equalsIgnoreCase("CURRENT"))) {
            System.out.println("Invalid account details.");
            return false;
        }
        if (accountType.equalsIgnoreCase("SAVINGS") && balance < 1000) {
            System.out.println("Savings account requires a minimum balance of 1000.");
            return false;
        }

        String sql = "INSERT INTO accounts " +
                     "(account_no, holder_name, account_type, balance, pin_hash) " +
                     "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, accountNo);
            ps.setString(2, holderName.trim());
            ps.setString(3, accountType.toUpperCase());
            ps.setDouble(4, balance);
            ps.setString(5, PinSecurity.hashPin(pin));
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            System.out.println("Account creation failed: " + e.getMessage());
            return false;
        }
    }

    public boolean verifyPin(int accountNo, String pin) {
        if (pin == null || !pin.matches("\\d{4,12}")) {
            System.out.println("PIN must contain 4 to 12 digits.");
            return false;
        }

        String sql = "SELECT pin_hash, locked FROM accounts WHERE account_no = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, accountNo);

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    System.out.println("Account not found.");
                    return false;
                }
                if (rs.getBoolean("locked")) {
                    System.out.println("Account is locked.");
                    return false;
                }
                String storedHash = rs.getString("pin_hash");
                if (PinSecurity.verifyPin(pin, storedHash)) {
                    resetAttempts(accountNo);
                    System.out.println("PIN verified successfully.");
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println("PIN verification failed: " + e.getMessage());
            return false;
        }

        recordFailedAttempt(accountNo);
        return false;
    }

    private boolean recordFailedAttempt(int accountNo) {
        String sql = "UPDATE accounts SET failed_attempts = failed_attempts + 1 " +
                     "WHERE account_no = ? AND locked = FALSE";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, accountNo);
            ps.executeUpdate();

            String checkSql = "SELECT failed_attempts FROM accounts WHERE account_no = ?";
            try (PreparedStatement check = con.prepareStatement(checkSql)) {
                check.setInt(1, accountNo);
                try (ResultSet rs = check.executeQuery()) {
                    if (rs.next() && rs.getInt("failed_attempts") >= 3) {
                        try (PreparedStatement lock = con.prepareStatement(
                                "UPDATE accounts SET locked = TRUE " +
                                "WHERE account_no = ? AND locked = FALSE")) {
                            lock.setInt(1, accountNo);
                            lock.executeUpdate();
                        }
                        System.out.println("Account locked after 3 incorrect PIN attempts.");
                        return false;
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Could not record failed attempt: " + e.getMessage());
            return false;
        }

        System.out.println("Incorrect PIN.");
        return false;
    }

    private void resetAttempts(int accountNo) {
        String sql = "UPDATE accounts SET failed_attempts = 0 WHERE account_no = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, accountNo);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Could not reset failed attempts: " + e.getMessage());
        }
    }
}
