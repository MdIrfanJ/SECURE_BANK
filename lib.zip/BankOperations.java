
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BankOperations {
    public void showBalance(int accountNo) {
        String sql = "SELECT holder_name, account_type, balance FROM accounts WHERE account_no = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, accountNo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    System.out.println("\n===== ACCOUNT DETAILS =====");
                    System.out.println("Holder: " + rs.getString("holder_name"));
                    System.out.println("Account Type: " + rs.getString("account_type"));
                    System.out.printf("Balance: Rs. %.2f%n", rs.getDouble("balance"));
                } else {
                    System.out.println("Account not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Unable to retrieve balance: " + e.getMessage());
        }
    }

    public boolean deposit(int accountNo, double amount) {
        if (amount <= 0) {
            System.out.println("Amount must be positive.");
            return false;
        }
        String sql = "UPDATE accounts SET balance = balance + ? WHERE account_no = ?";
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setDouble(1, amount);
                    ps.setInt(2, accountNo);
                    if (ps.executeUpdate() != 1) {
                        con.rollback();
                        System.out.println("Account not found.");
                        return false;
                    }
                }
                recordTransaction(con, accountNo, "DEPOSIT", amount);
                con.commit();
                System.out.println("Deposit successful.");
                return true;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            System.out.println("Deposit failed: " + e.getMessage());
            return false;
        }
    }

    public boolean withdraw(int accountNo, double amount) throws InsufficientFundsException {
        if (amount <= 0) {
            System.out.println("Amount must be positive.");
            return false;
        }
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                String sql = "SELECT account_type, balance FROM accounts WHERE account_no = ? FOR UPDATE";
                String type;
                double balance;
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, accountNo);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            con.rollback();
                            System.out.println("Account not found.");
                            return false;
                        }
                        type = rs.getString("account_type");
                        balance = rs.getDouble("balance");
                    }
                }
                double newBalance = balance - amount;
                if (type.equals("SAVINGS") && newBalance < 1000) {
                    con.rollback();
                    throw new InsufficientFundsException(
                        "Withdrawal denied: Savings account must maintain Rs. 1000.");
                }
                if (type.equals("CURRENT") && newBalance < -5000) {
                    con.rollback();
                    throw new InsufficientFundsException(
                        "Withdrawal denied: Current account overdraft limit exceeded.");
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE accounts SET balance = ? WHERE account_no = ?")) {
                    ps.setDouble(1, newBalance);
                    ps.setInt(2, accountNo);
                    ps.executeUpdate();
                }
                recordTransaction(con, accountNo, "WITHDRAWAL", amount);
                con.commit();
                System.out.println("Withdrawal successful.");
                return true;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            System.out.println("Withdrawal failed: " + e.getMessage());
            return false;
        }
    }

    public boolean transfer(int fromAccount, int toAccount, double amount)
            throws InsufficientFundsException {
        if (amount <= 0 || fromAccount == toAccount) {
            System.out.println("Invalid transfer details.");
            return false;
        }
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                String sql = "SELECT account_type, balance FROM accounts WHERE account_no = ? FOR UPDATE";
                String fromType;
                double fromBalance;
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, fromAccount);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            con.rollback();
                            System.out.println("Source account not found.");
                            return false;
                        }
                        fromType = rs.getString("account_type");
                        fromBalance = rs.getDouble("balance");
                    }
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT account_no FROM accounts WHERE account_no = ?")) {
                    ps.setInt(1, toAccount);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            con.rollback();
                            System.out.println("Destination account not found.");
                            return false;
                        }
                    }
                }
                double newBalance = fromBalance - amount;
                if (fromType.equals("SAVINGS") && newBalance < 1000) {
                    con.rollback();
                    throw new InsufficientFundsException(
                        "Transfer denied: Savings account must maintain Rs. 1000.");
                }
                if (fromType.equals("CURRENT") && newBalance < -5000) {
                    con.rollback();
                    throw new InsufficientFundsException(
                        "Transfer denied: Current account overdraft limit exceeded.");
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE accounts SET balance = balance - ? WHERE account_no = ?")) {
                    ps.setDouble(1, amount);
                    ps.setInt(2, fromAccount);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE accounts SET balance = balance + ? WHERE account_no = ?")) {
                    ps.setDouble(1, amount);
                    ps.setInt(2, toAccount);
                    ps.executeUpdate();
                }
                recordTransaction(con, fromAccount, "TRANSFER_OUT", amount);
                recordTransaction(con, toAccount, "TRANSFER_IN", amount);
                con.commit();
                System.out.println("Transfer successful.");
                return true;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            System.out.println("Transfer failed: " + e.getMessage());
            return false;
        }
    }

    public boolean addYearlyInterest(int accountNo) {
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                String sql = "SELECT account_type, balance FROM accounts WHERE account_no = ? FOR UPDATE";
                String type;
                double balance;
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, accountNo);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            con.rollback();
                            System.out.println("Account not found.");
                            return false;
                        }
                        type = rs.getString("account_type");
                        balance = rs.getDouble("balance");
                    }
                }
                if (!type.equals("SAVINGS")) {
                    con.rollback();
                    System.out.println("Yearly interest is available only for savings accounts.");
                    return false;
                }
                double interest = balance * 0.04;
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE accounts SET balance = balance + ? WHERE account_no = ?")) {
                    ps.setDouble(1, interest);
                    ps.setInt(2, accountNo);
                    ps.executeUpdate();
                }
                recordTransaction(con, accountNo, "INTEREST", interest);
                con.commit();
                System.out.printf("Yearly interest added: Rs. %.2f%n", interest);
                System.out.printf("New balance: Rs. %.2f%n", balance + interest);
                return true;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            System.out.println("Unable to add interest: " + e.getMessage());
            return false;
        }
    }

    private void recordTransaction(Connection con, int accountNo,
                                   String type, double amount) throws SQLException {
        String sql = "INSERT INTO transactions (account_no, transaction_type, amount) VALUES (?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, accountNo);
            ps.setString(2, type);
            ps.setDouble(3, amount);
            ps.executeUpdate();
        }
    }
}
